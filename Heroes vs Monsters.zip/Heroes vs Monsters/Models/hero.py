from Models.character import Character

class Hero(Character):
    def __str__(self):
        return "H"
