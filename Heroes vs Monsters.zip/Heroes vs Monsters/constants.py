GRID_SIZE = 5
MONSTERS_COUNT = 10

MONSTERS = ["Wolf", "Wyrmling", "Orc"]
HEROES = ["Human", "Dwarf"]

LEATHER = "Leather"
GOLD = "Gold"